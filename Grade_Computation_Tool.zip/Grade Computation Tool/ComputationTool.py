from flask import Flask, render_template, request

app = Flask(__name__)

def calculate_required_grades(prelim_grade):
    passing_grade = 75
    prelim_weight = 0.20
    midterm_weight = 0.30
    final_weight = 0.50
    grade_range = (0, 100)
    
#Computation of prelim grade to 20%
    current_total = prelim_grade * prelim_weight
#Calculation of grades required for midterm and finals
    required_total = passing_grade - current_total
    midterm_final_weight = midterm_weight + final_weight
#Calculation of average grades required for midterm and finals
    min_required_average = required_total / midterm_final_weight

#To make sure the grades entered is only between 0 and 100
    if not (grade_range[0] <= prelim_grade <= grade_range[1]):
        return "Error: Preliminary grade must be between 0 and 100."

    if min_required_average < grade_range[0]:
        min_required_average = grade_range[0]
    return "Required Grade for Midterm and Finals to Pass: {:.2f}".format(min_required_average)

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    if request.method == 'POST':
#Gets the prelim grade from the form (from index.html)
        prelim_grade = float(request.form['prelim_grade'])
#Calculation for the required grade and store the result
        result = calculate_required_grades(prelim_grade)
    return render_template('index.html', result=result)
    

if __name__ == '__main__':
    app.run(debug=True)