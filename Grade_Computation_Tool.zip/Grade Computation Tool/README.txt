README file

This project is a web application for the required grades to pass the semester by only
entering your prelim grade, this progject is built using Python, HTML, and Flask

Installation
-Download the Grade_Computation_Tool.zip file and extract it
-Install the required package using 'pip install Flask' on cmd

Running the Application
-Open the folder on VSCode
-Navigate the project directory 'cd your-folder-name'
-Run the application using 'python ComputationTool.py'
-Run the program
-Open a web browser and navigate to 'http://localhost:5000' to access the application

Using the Application
-Enter your Prelim Grade
-Click Calculate Button
-Result will show the required grades you need to pass the semester

